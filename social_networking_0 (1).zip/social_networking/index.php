<?php require_once('./config.php'); ?>
<?php redirect('./user'); ?>
